<?php
ob_start();
require_once './db_connect_PDO.php';
require_once'./scripts_PDO.php';
session_start();
   $id = $_SESSION[session_id()];
   $uzivatel = getUserLogin($_SESSION[session_id()], $db);
   
   echo "<h1>Moje rezervace</h1><br />";
   echo "uzivatel: $uzivatel a jeho rezervace<br /><br />";
   
   //dlouhy, ale asi jediny mozny dotaz jak vytahnout vsechnu rezervace
   try {
         $query = $db->prepare("SELECT *,ucebna_rezervace_hodina 
         FROM ucebna_mistnost JOIN ucebna_rezervace ON ucebna_mistnost.ucebna_id = ucebna_rezervace.ucebna_rezervace_iducebny
      WHERE ucebna_rezervace_idUzivatel = ?");  
   } catch (PDOException $e) {
       die($e->getMessage());
    } 
    
   //parametry
    $params = array($id);
     //dotaz spustim
    try {
        $query->execute($params);
    } catch (PDOException $e) {
        die($e->getMessage());
    } 
    echo "<table border=\'1\'>";
    echo("<tr> <td>Ucebna</td><td>Vybaveni</td><td>Kapacita</td><td>Hodina</td><td>&nbsp;</td>
          </tr>");  
                         
                          while($row = $query->fetch(PDO::FETCH_BOTH)) {                        			
                            
                            $ucebna_id = $row['ucebna_id'];
                            $ucebna_cislo = $row['ucebna_cislo'];
                            $ucebna_popis = $row['ucebna_popis'];
                            $ucebna_kapacita = $row['ucebna_kapacita'];
                            $ucebna_rezervace_hodina = $row['ucebna_rezervace_hodina'];
                       
                            
                            echo("<tr> <td>$ucebna_cislo</td>
                              <td>$ucebna_popis</td>
                              <td>$ucebna_kapacita</td>
                              <td>$ucebna_rezervace_hodina</td>
                              <td><a href='./puj_vratit.php?id=$ucebna_id&den=$ucebna_rezervace_hodina'>Zrusit</a></td></tr>\n");
       
                          } 
                          echo "</table>";
                          echo "<a href='./puj_index.php'>Zpet</a> ";  
                          
                          ?>          
                          
                      