<?php
    //nastartovani session
    session_start();
    //output buffering
    ob_start();
    //pripojeni k DB
    require_once './db_connect_PDO.php';
    //scripty
    require_once './scripts_PDO.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Rezervace Uceben</title>
        <link rel="stylesheet" type="text/css" href="./styl.css">
    </head>
    <?php
        //promenna pro chybova hlaseni - dokud je prazdna tak nenastala zadna chyba
        $chyba = "";
        //uzivatel se chce prihlasit
        if(isset($_REQUEST['puj_prihl'])) {
            //vytahnu si jeho login a heslo
            //$login = htmlspecialchars(mysql_real_escape_string(($_REQUEST['puj_login'])));
            $login = htmlspecialchars($_REQUEST['puj_login']);
            //$heslo = htmlspecialchars(mysql_real_escape_string(($_REQUEST['puj_heslo'])));
            $heslo = htmlspecialchars($_REQUEST['puj_heslo']);
            //pokud zadal login nebo heslo prazdne, koncim s chybou
            if(($login == '') || ($heslo == '')) {
                $chyba = "Vyplnte login a heslo";
            } else {
                //jinak spocitam hash z jeho hesla
                $heslo = md5($heslo);
                //pokusim se prihlasit
                if(userLogin($login, $heslo, $db)) {
                    //pokud se to povedlo
                    //vytahnu si id uzivatele ze session
                    $id = $_SESSION[session_id()];
                    //zjistim si jeho login kvuli vypisu kdo je prihlasen
                    $login = getUserLogin($id, $db);
                } else {
                    //pokud to nenaslo shodu, vypisu chybou hlasku
                    $chyba = "Neplatny login a heslo";
                }
            }
        //uzivatel se chce odhlasit
        } else if(isset($_REQUEST['puj_odhl'])) {
            //pokusim se odhlasit
            if(!userLogout()) {
                //pokud se to nepovedlo, vypisu chybovou hlasku
                $chyba = "Odhlaseni se nezdarilo";
            }
        }
    ?>
    <body>
        <!--div pro hlavicku, zobrazuje pouze nadpis, je v extra wrapperu, kvuli layoutu a border-->
        <div id="wrap_head">
            <div id="head">
                <h1>Rezervace Uceben</h1>
            </div>
        </div>
        <!--div pro telo, zobrazuje vsechny knihy a podle toh jestli je uzivatel prihlasen, nebo ne umoznuje jejich pujcovani, je v extra wrapperu, kvuli layoutu a border-->
        <div id="wrap_body">
            <div id="body">
                <?php
                    //vytahnu si informace o vsech pokojich v db
                    try {
                        $query = $db->prepare("SELECT * FROM ucebna_mistnost");
                    } catch (PDOException $e) {
                        die($e->getMessage());
                    }
                    try {
                        $query->execute();
                    } catch (PDOException $e) {
                        die($e->getMessage());
                    }
                    //pokud je uzivatel prihlasen
                  if(isLoggedIn()) {
                        //vytahnu si jeho id, kvuli identifikaci
                        $id = $_SESSION[session_id()];
                        echo("<table border='1'>\n");
                        echo("<tr> <th rowspan = '2'>Ucebna</th> <th rowspan = '2'>Vybaveni</th> <th rowspan = '2'>Kapacita</th>
                        <th colspan = '9'> Rezervace</th></tr><tr><th>08:00</th><th>09:00</th><th>10:00</th><th>11:00</th><th>12:00</th><th>13:00</th>
                        <th>14:00</th><th>15:00</th><th>16:00</th> </tr>\n");
                        echo "<tr>";
                        while($row = $query->fetch(PDO::FETCH_BOTH)) {                        			
                            //vytahnu si id pokoje - kvuli pujcovani a vraceni
                            $ucebna_id = $row['ucebna_id'];
                            $ucebna_cislo = $row['ucebna_cislo'];
                            $ucebna_popis = $row['ucebna_popis'];
                            $ucebna_kapacita = $row['ucebna_kapacita'];
                            
                            echo "<td>$ucebna_cislo</td><td>$ucebna_popis</td><td>$ucebna_kapacita</td>";			
                            
                            //jadro programu, pro 9 casu musim generovat 9x dotaz, kde mam diky promenne i parametr pro samotne hodiny
                            for ($i = 0; $i < 9;$i++){
                            
                            try {
                                $query2 = $db->prepare("SELECT ucebna_rezervace_idUzivatel FROM ucebna_rezervace WHERE ucebna_rezervace_iducebny = ? AND ucebna_rezervace_hodina = ?");
                            } catch (PDOException $e) {
                                die($e->getMessage());
                            }
                            //parametry
                            $params = array($ucebna_id, $i);
                            //dotaz spustim
                            try {
                                $query2->execute($params);
                            } catch (PDOException $e) {
                                die($e->getMessage());
                            }
                            $pom = $query2->fetchColumn(0);
                            if($pom == $id) {
                                //v pomocn ulozen vysledek dotazu na obsazenost pokoje, pokud je shodny s mym id, muzu rusit
                                echo("<td><a href='./puj_vratit.php?id=$ucebna_id&den=$i'>Zrusit</a></td>\n");
                            } else if($pom > 0) {
                                //pokud nebyl vysledek moje ID, ale nabyva nejake hodnoty, je jiz pokoj obsazen
                                echo("<td>Obsazeno</td>\n");
                            } else {
                                //v ostatnich pripadech lze rezervovat
                                echo("<td><a href='./puj_pujcit.php?id=$ucebna_id&den=$i'>Rezervovat</a></td>\n");  
                              }                            
                            }
                            echo "</tr>";     
                            
                            }
                        echo("</table>");      
                    } else {
                        //pokud si stranku prohlizi neprihlaseny uzivatel, zobrazim mu pouze prehled a hlaseni ze se musi prihlasit
                        echo("<table border='1'>\n");
                        echo("<tr> <th rowspan = '2'>Ucebna</th> <th rowspan = '2'>Vybaveni</th> <th rowspan = '2'>Kapacita</th>
                        <th colspan = '9'> Rezervace</th></tr><tr><th>08:00</th><th>09:00</th><th>10:00</th><th>11:00</th><th>12:00</th><th>13:00</th>
                        <th>14:00</th><th>15:00</th><th>16:00</th> </tr>\n");
                        echo "<tr>";
                        while($row = $query->fetch(PDO::FETCH_BOTH)) {                        			
                            //vytahnu si id pokoje - kvuli pujcovani a vraceni
                            $ucebna_id = $row['ucebna_id'];
                            $ucebna_cislo = $row['ucebna_cislo'];
                            $ucebna_popis = $row['ucebna_popis'];
                            $ucebna_kapacita = $row['ucebna_kapacita'];
                            
                            echo "<td>$ucebna_cislo</td><td>$ucebna_popis</td><td>$ucebna_kapacita</td>";			
                            
                            //jadro programu, pro 9 casu musim generovat 9x dotaz, kde mam diky promenne i parametr pro samotne hodiny
                            for ($i = 0; $i < 9;$i++){
                            
                            try {
                                $query2 = $db->prepare("SELECT ucebna_rezervace_idUzivatel FROM ucebna_rezervace WHERE ucebna_rezervace_iducebny = ? AND ucebna_rezervace_hodina = ?");
                            } catch (PDOException $e) {
                                die($e->getMessage());
                            }
                            //parametry
                            $params = array($ucebna_id, $i);
                            //dotaz spustim
                            try {
                                $query2->execute($params);
                            } catch (PDOException $e) {
                                die($e->getMessage());
                            }
                            $pom = $query2->fetchColumn(0);
                            if($pom == $id) {
                                //v pomocn ulozen vysledek dotazu na obsazenost pokoje, pokud je shodny s mym id, muzu rusit
                                echo("<td>&nbsp;</td>\n");
                            } else if($pom > 0) {
                                //pokud nebyl vysledek moje ID, ale nabyva nejake hodnoty, je jiz pokoj obsazen
                                echo("<td>Obsazeno</td>\n");
                            } else {
                                //v ostatnich pripadech lze rezervovat
                                echo("<td>&nbsp;</td>\n");  
                              }                            
                            }
                            echo "</tr>";     
                            
                            }
                        echo("</table>");  
                    }
                ?>
            </div>
        </div>
        <!--div pro login, zobrazuje bud prihlasovaci, nebo odhlasovaci formular podle stavu uzivatele, je v extra wrapperu, kvuli layoutu a border-->
        <div id="wrap_login">
            <div id="login">
                <?php
                    if(!isLoggedIn()) {
                        //pokud je uzivatel odhlasen zobrazuje prihlasovaci formular
                        echo("<form action='' method='POST'>\n");
                        echo("login: <input type='text' name='puj_login'><br>\n");
                        echo("heslo: <input type='password' name='puj_heslo'><br>\n");
                        echo("<input type='submit' name='puj_prihl' value='Prihlasit'>\n");
                        //pokud nekde pred tim nastala chyba - promenna pro chybu neni prazdna tak ji vypis
                        if($chyba != '') {
                            echo("<p class='error'> $chyba </p>\n");
                        }
                        echo("</form>\n");
                        //link na registracni formular
                        echo("<a href='./puj_register.php'>Registrace</a>\n");
                    } else {
                        //pokud je uzivatel prihlasen, zobrazuje kdo je prihlasen a formular pro odhlaseni
                        echo("Prihlasen: " . getUserLogin($_SESSION[session_id()], $db) . "<br>\n");
                        echo("<form action='' method='POST'>\n");
                        echo("<input type='submit' name='puj_odhl' value='Odhlasit'>\n");
                        echo("</form>\n");
                        echo "<a href='./rezervace.php'>Moje rezervace</a> ";
                      
                        
                    }
                    
                ?>
            </div>
        </div>
    </body>
</html>
<?php
    //output buffering
    ob_end_flush();
?>