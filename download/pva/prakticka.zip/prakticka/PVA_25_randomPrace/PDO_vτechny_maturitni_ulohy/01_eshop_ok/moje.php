<?php
ob_start();
require_once './db_connect_PDO.php';
require_once'./scripts_PDO.php';
session_start();
   $id = $_SESSION[session_id()];
   $uzivatel = getUserLogin($_SESSION[session_id()], $db);
   
   echo "<h1>Nakupni kosik</h1><br />";
   echo "uzivatel: $uzivatel a jeho kosik<br /><br />";
   

   try {
         $query = $db->prepare("SELECT *,pocet,id_zbozi_uziv FROM zbozi JOIN zbozi_uziv ON zbozi.ID_zbozi = zbozi_uziv.id_zbozi WHERE id_uzivatele = ?");  
   } catch (PDOException $e) {
       die($e->getMessage());
    } 
    
   //parametry
    $params = array($id);
     //dotaz spustim
    try {
        $query->execute($params);
    } catch (PDOException $e) {
        die($e->getMessage());
    } 
                        $celkem = 0;
                        echo("<table border=\"1\">");
                        echo("<th>Nazev</th><th>Kategorie</th><th>Pocet</th><th>Cena za ks</th><th>Cena celkem</th><th>&nbsp;</th>");
                        while($row = $query->fetch(PDO::FETCH_BOTH)){
                            $ID_zbozi = $row['ID_zbozi'];
                            $nazev_zbozi = $row['nazev_zbozi'];
                            $kategorie_zbozi = $row['kategorie_zbozi'];
                            $pocet_zbozi = $row['pocet'];
                            $cena_zbozi = $row['cena_zbozi'];
                            $id_zbozi_uziv = $row['id_zbozi_uziv'];
                            $cena = $pocet_zbozi * $cena_zbozi;
                            $celkem = $celkem + $cena;
                          
                            
                            echo("<tr> <td>$nazev_zbozi</td><td>$kategorie_zbozi</td>
                            <td>$pocet_zbozi</td><td>$cena_zbozi</td><td>$cena</td>
                            <td><a href='./zrusit.php?id=$id_zbozi_uziv'>Odebrat z kosiku</a></td>");
                            echo ("</tr>");
                            $cena = 0;
                        }    
                        echo "<tr><td colspan = '3'>Celkem</td><td>&nbsp;</td><td>$celkem</td><td>&nbsp;</td></tr>"; 
                        echo "</table>";
                        echo "<a href='./eshop_index.php'>Zpet</a> "; 
                          ?>              