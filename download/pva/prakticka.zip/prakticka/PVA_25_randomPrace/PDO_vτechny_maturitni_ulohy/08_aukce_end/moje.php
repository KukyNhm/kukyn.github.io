<?php
ob_start();
require_once './db_connect_PDO.php';
require_once'./scripts_PDO.php';
session_start();
   $id = $_SESSION[session_id()];
   $uzivatel = getUserLogin($_SESSION[session_id()], $db);
   
   echo "<h1>Moje aukce</h1><br />";
   echo "uzivatel: $uzivatel a jeho aukce<br /><br />";
   
   //dlouhy, ale asi jediny mozny dotaz jak vytahnout vsechnu rezervace
   try {
         $query = $db->prepare("SELECT * FROM zbozi WHERE ID_vlastnika = ?");  
   } catch (PDOException $e) {
       die($e->getMessage());
    } 
    
   //parametry
    $params = array($id);
     //dotaz spustim
    try {
        $query->execute($params);
    } catch (PDOException $e) {
        die($e->getMessage());
    } 
                        echo("<table border=\"1\">");
                        echo("<th>Nazev</th><th>Popis</th><th>Kategorie</th><th>Pocet</th><th>Cena</th>");
                        while($row = $query->fetch(PDO::FETCH_BOTH)){
                            $ID_zbozi = $row['ID_zbozi'];
                            $nazev_zbozi = $row['nazev_zbozi'];
                            $popis_zbozi = $row['popis_zbozi'];
                            $kategorie_zbozi = $row['kategorie_zbozi'];
                            $pocet_zbozi = $row['pocet_zbozi'];
                            $cena_zbozi = $row['cena_zbozi'];
                            
                            
                            
                            echo("<tr> <td>$nazev_zbozi</td><td>$popis_zbozi</td><td>$kategorie_zbozi</td>
                            <td>$pocet_zbozi</td>");
                            if ($cena_zbozi == "") {echo "<td colspan = '2'>nikdo neprihazuje</td>";
                            }else {echo ("<td>$cena_zbozi</td>");}
                            echo ("</tr>");
                            
                        } 
                        echo "</table>";
                        echo "<a href='./aukce_index.php'>Zpet</a> "; 
                          ?>              