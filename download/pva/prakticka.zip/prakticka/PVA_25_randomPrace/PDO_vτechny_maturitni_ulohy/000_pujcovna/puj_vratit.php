<?php
    //script pro vraceni knihy - vyzaduje v REQUESTU id vracene knihy
    //nastartovani prace se session
    session_start();
    //output buffering - kvuli hlasce s odeslanymi hlavickami
    ob_start();
    //require souboru pro pripojeni k db
    require_once './db_connect_PDO.php';
    //require souboru s  funkcemi
    require_once'./scripts_PDO.php';
    //vratit knihu muze pouze prihlaseny uzivatel
    if(isLoggedIn()) {
        //pokud prislo v REQUESTU id knihy
        if(isset($_REQUEST['id'])) {
            //vytahnu si id z REQUESTU
            //$kniha_id = htmlspecialchars(mysql_real_escape_string(($_REQUEST['id'])));
            $kniha_id = htmlspecialchars($_REQUEST['id']);
            //vytahnu si id uzivatele
            $id = $_SESSION[session_id()];
            //vytahnu si z db zda ma dany uzivatel danou knihu pujcenu, bud 1 nebo 0 zaznamu
            try {
                $query = $db->prepare("SELECT COUNT(*) FROM puj_vypujcky WHERE puj_vyp_idKniha = ? AND puj_vyp_idUzivatel = ?");
            } catch (PDOException $e) {
                die($e->getMessage());
            }
            //parametry
            $params = array($kniha_id, $id);
            //dotaz spustim
            try {
                $query->execute($params);
            } catch (PDOException $e) {
                die($e->getMessage());
            }
            if($query->fetchColumn(0) == 1) {
                //pokud je pocet zaznum 1 - ma ji pujcenu
                //vratim knihu - zvysim jeji pocet o jedna
                try {
                    $query = $db->prepare("UPDATE puj_knihy SET puj_knihy_pocet = puj_knihy_pocet + 1 WHERE puj_knihy_id = ?");
                } catch (PDOException $e) {
                    die($e->getMessage());
                }
                //parametry
                $params = array($kniha_id);
                //dotaz spustim
                try {
                    $result = $query->execute($params);
                } catch (PDOException $e) {
                    die($e->getMessage());
                }
                //kontrola provedeni
                if($result == FALSE) {
                    die("Chyba pri update");
                }
                //vymazu zaznam z tabulky vypujcky - uzivatel daneho id vratil knihu daneho id
                try {
                    $query = $db->prepare("DELETE FROM puj_vypujcky WHERE puj_vyp_idUzivatel = ? AND puj_vyp_idKniha = ?");
                } catch (PDOException $e) {
                    die($e->getMessage());
                }
                //parametry
                $params = array($id, $kniha_id);
                //dotaz spustim
                try {
                    $result = $query->execute($params);
                } catch (PDOException $e) {
                    die($e->getMessage());
                }
                //kontrola provedeni
                if($result == FALSE) {
                    die("Chyba pri delete");
                }
            }
        }
    }
    //presmeruji zpet na index
    header("Location: ./puj_index.php");
    //output buffering - kvuli hlasce s odeslanymi hlavickami
    ob_end_flush();
?>