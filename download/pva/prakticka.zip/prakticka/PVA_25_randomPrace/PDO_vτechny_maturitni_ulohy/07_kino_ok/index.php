<?php
    session_start();
    ob_start();
    require_once './db_connect_PDO.php';
    require_once'./scripts_PDO.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Kino</title>
        <link rel="stylesheet" type="text/css" href="./styl.css" />
    </head>
    <body>
        <?php
        //promenna ktera zobrazi chyby
        $chyba = "";
            // uzivatel se chce prihlasit
            if(isset($_REQUEST['puj_prihl'])){
                //vytahnu si login
                $login = htmlspecialchars($_REQUEST['puj_login']);
                $heslo = htmlspecialchars($_REQUEST['puj_heslo']);
                //zkontroluji zda nejsou prazdne
                if(($login == "") || ($heslo == "")){
                    $chyba = "Vyplnte login a heslo";
                }else{
                    $heslo = md5($heslo);
                    if(userLogin($login, $heslo, $db)){
                        //pokud se podarilo prihlaseni
                        //vytahnu si id uzivatele
                        $id = $_SESSION[session_id()];
                        //vytahnu si uzivateluv login
                        $login = getUserLogin($id, $db);
                    }else{
                        $chyba = "Neplatny login a heslo";
                    }
                }
            }else if(isset($_REQUEST['puj_odhl'])) {
                //pokusim se prihlasit
                if(!userLogout()){
                    //pokud se nepovede odhlaseni 
                    $chyba = "Odhlaseni se nezdarilo";
                }
            }
        ?>
        <div id="wrap_head">
            <div id="head">
                <h1>Rezervace sedadel</h1>
            </div>
        </div>
        <div id="wrap_body">
            <div id="body">
                <?php
                    //info o knihach
                    try {
                        $query = $db->prepare("SELECT * FROM kino_saly");
                        $query->execute();
                    } catch (PDOException $e) {
                        die($e->getMessage());
                    }
                    //pokud je uzivatel prihlasen
                    if(isLoggedIn()){
                      $id = $_SESSION[session_id()];
                      //tabulku si prohlizi prihlaseny
                        while($row = $query->fetch(PDO::FETCH_BOTH)){
                            $sal = $row['kino_saly_nazev'];
                            $program = $row['kino_saly_program'];
                            $sal_id = $row['kino_saly_id'];
                            echo("<h3>$sal</h3><br />");
                            echo("Program: $program<br />");
                            echo("Sedadla<br /><br />");
                            
                            echo("<table border=\"1\">");
                            echo("<tr> <td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td> <td>10</td></tr>");
                            
                            for ($i = 0; $i < 10;$i++){
                            
                            try {
                                $query2 = $db->prepare("SELECT kino_rezervace_idUzivatel FROM kino_rezervace WHERE kino_rezervace_idSal = ? AND kino_rezervace_kreslo = ?");
                            } catch (PDOException $e) {
                                die($e->getMessage());
                            }
                            //parametry
                            $params = array($sal_id, $i);
                            //dotaz spustim
                            try {
                                $query2->execute($params);
                            } catch (PDOException $e) {
                                die($e->getMessage());
                            }
                            $pom = $query2->fetchColumn(0);
                            if($pom == $id) {
                                //v pomocn ulozen vysledek dotazu na obsazenost pokoje, pokud je shodny s mym id, muzu rusit
                                echo("<td rowspan='3'><a href='./puj_vratit.php?id=$sal_id&den=$i'>Zrusit</a></td>\n");
                            } else if($pom > 0) {
                                //pokud nebyl vysledek moje ID, ale nabyva nejake hodnoty, je jiz pokoj obsazen
                                echo("<td rowspan='3'>Obsazeno</td>\n");
                            } else {
                                //v ostatnich pripadech lze rezervovat
                                echo("<td rowspan='3'><a href='./puj_pujcit.php?id=$sal_id&den=$i'>Rezervovat</a></td>\n");  
                              }                            
                            }
                            echo("</table>");
                          }
                        
                    } else {
                        //tabulku si prohlizi neprihlaseny
                        while($row = $query->fetch(PDO::FETCH_BOTH)){
                            $sal = $row['kino_saly_nazev'];
                            $program = $row['kino_saly_program'];
                            $sal_id = $row['kino_saly_id'];
                            echo("<h3>$sal</h3><br />");
                            echo("Program: $program<br />");
                            echo("Sedadla<br /><br />");
                            
                            echo("<table border=\"1\">");
                            echo("<tr> <td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td> </tr>");
                            
                            try {
                                $query2 = $db->prepare("SELECT COUNT(*) FROM puj_vypujcky WHERE puj_vyp_idUzivatel = ? AND kino_rezervace_kreslo = ?");
                            } catch (PDOException $e) {
                                die($e->getMessage());
                            }
                            
                            echo("<tr> <td></td> </tr>");
                            echo("</table>");
                        }
                    }
                ?>
            </div>
        </div>
        <div id="wrap_login">
            <div id="login">
                <?php
                    if(!isLoggedIn()){
                        //nejsem prihlasen zobraz prihl form
                        echo("<form action=\"\" method=\"POST\">\n");
                        echo("Login: <input type=\"text\" name=\"puj_login\" /><br />\n");
                        echo("Heslo: <input type=\"password\" name=\"puj_heslo\" /><br />\n");
                        echo("<input type=\"submit\" name=\"puj_prihl\" value=\"Prihlasit\"/>\n");
                        echo("</form>\n");
                        //zobrazeni chyby
                        if($chyba != ""){
                            echo("<p class=\"error\"> $chyba </p> ");
                        }
                    }else{
                        //jsem prihlasen
                        echo("Prihlasen: " . getUserLogin($_SESSION[session_id()], $db) . "<br />");
                        echo("<form action=\"\" method=\"POST\">\n");
                        echo("<input type=\"submit\" name=\"puj_odhl\" value=\"Odhlasit\"/>\n");
                        echo("</form>\n");
                        echo "<a href='./rezervace.php'>Moje rezervace</a> ";
                    }
                ?>
            </div>
        </div>
    </body>
</html>
<?php
    ob_end_flush();
?>