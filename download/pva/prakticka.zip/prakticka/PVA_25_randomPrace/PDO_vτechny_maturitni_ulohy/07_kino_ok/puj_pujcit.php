<?php
    //script pro vypujceni knihy - vyzaduje v REQUESTU id pujcovane knihy
    //nastartovani prace se session
    session_start();
    //output buffering - kvuli hlasce s odeslanymi hlavickami
    ob_start();
    //require souboru pro pripojeni k db
    require_once './db_connect_PDO.php';
    //require souboru s  funkcemi
    require_once'./scripts_PDO.php';
    //pujcovat muze jenom prihlaseny uzivatel
    if(isLoggedIn()) {
        //pokud prislo v REQUESTU id 
        if(isset($_REQUEST['id'])) {
            //vytahnu si id z REQUESTU
            $kniha_id = htmlspecialchars($_REQUEST['id']);
            $den = htmlspecialchars($_REQUEST['den']);
            $id = $_SESSION[session_id()];
            //natvrdo pridam zaznam, neni mozno prolomit z duvodu, ze v parametru pouzivam session ID 
            try {
                $query = $db->prepare("INSERT INTO kino_rezervace (kino_rezervace_idUzivatel, kino_rezervace_idSal, kino_rezervace_kreslo) VALUES (?, ?, ?)");
            } catch (PDOException $e) {
                die($e->getMessage());
            }
            //parametry
            $params = array($id,$kniha_id, $den);
            //dotaz spustim
            try {
                $query->execute($params);
            } catch (PDOException $e) {
                die($e->getMessage());
            }
            
        }
    }
    //presmeruji zpet na index
    header("Location: ./index.php");
    //output buffering - kvuli hlasce s odeslanymi hlavickami
    ob_end_flush();
?>