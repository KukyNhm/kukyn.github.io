<?php
    //nastartovani session
    session_start();
    //output buffering
    ob_start();
    //pripojeni k DB
    require_once './db_connect_PDO.php';
    //scripty
    require_once './scripts_PDO.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Pujcovna</title>
        <link rel="stylesheet" type="text/css" href="./styl.css">
    </head>
    <?php
        //promenna pro chybova hlaseni - dokud je prazdna tak nenastala zadna chyba
        $chyba = "";
        //uzivatel se chce prihlasit
        if(isset($_REQUEST['puj_prihl'])) {
            //vytahnu si jeho login a heslo
            //$login = htmlspecialchars(mysql_real_escape_string(($_REQUEST['puj_login'])));
            $login = htmlspecialchars($_REQUEST['puj_login']);
            //$heslo = htmlspecialchars(mysql_real_escape_string(($_REQUEST['puj_heslo'])));
            $heslo = htmlspecialchars($_REQUEST['puj_heslo']);
            //pokud zadal login nebo heslo prazdne, koncim s chybou
            if(($login == '') || ($heslo == '')) {
                $chyba = "Vyplnte login a heslo";
            } else {
                //jinak spocitam hash z jeho hesla
                $heslo = md5($heslo);
                //pokusim se prihlasit
                if(userLogin($login, $heslo, $db)) {
                    //pokud se to povedlo
                    //vytahnu si id uzivatele ze session
                    $id = $_SESSION[session_id()];
                    //zjistim si jeho login kvuli vypisu kdo je prihlasen
                    $login = getUserLogin($id, $db);
                } else {
                    //pokud to nenaslo shodu, vypisu chybou hlasku
                    $chyba = "Neplatny login a heslo";
                }
            }
        //uzivatel se chce odhlasit
        } else if(isset($_REQUEST['puj_odhl'])) {
            //pokusim se odhlasit
            if(!userLogout()) {
                //pokud se to nepovedlo, vypisu chybovou hlasku
                $chyba = "Odhlaseni se nezdarilo";
            }
        }
    ?>
    <body>
        <!--div pro hlavicku, zobrazuje pouze nadpis, je v extra wrapperu, kvuli layoutu a border-->
        <div id="wrap_head">
            <div id="head">
                <h1>Rezervace pokoju</h1>
            </div>
        </div>
        <!--div pro telo, zobrazuje vsechny knihy a podle toh jestli je uzivatel prihlasen, nebo ne umoznuje jejich pujcovani, je v extra wrapperu, kvuli layoutu a border-->
        <div id="wrap_body">
            <div id="body">
                <?php
                    //vytahnu si informace o vsech pokojich v db
                    try {
                        $query = $db->prepare("SELECT * FROM hotel_pokoje");
                    } catch (PDOException $e) {
                        die($e->getMessage());
                    }
                    try {
                        $query->execute();
                    } catch (PDOException $e) {
                        die($e->getMessage());
                    }
                    //pokud je uzivatel prihlasen
                  if(isLoggedIn()) {
                        //vytahnu si jeho id, kvuli identifikaci
                        $id = $_SESSION[session_id()];
                        echo("<table border='1'>\n");
                        echo("<tr> <th>Pokoj</th> <th>Pond�l�</th> <th>�ter�</th> <th>St�eda</th> <th>�tvrtek</th> <th>P�tek</th> <th>Sobota</th> <th>Ned�le</th> </tr>\n");
                        while($row = $query->fetch(PDO::FETCH_BOTH)) {                        			
                            //vytahnu si id pokoje - kvuli pujcovani a vraceni
                            $hotel_pokoje_id = $row['hotel_pokoje_id'];
                            $hotel_pokoje_cislo = $row['hotel_pokoje_cislo'];
                            $hotel_pokoje_popis = $row['hotel_pokoje_popis'];
                            $hotel_pokoje_kapacita = $row['hotel_pokoje_kapacita'];
                        
                            echo("<tr> <td>$hotel_pokoje_cislo</td>");
                            //jadro programu, pro 7 dni musim generovat 7x dotaz, kde mam diky promenne i parametr pro samotne dny
                            for ($i = 0; $i < 7;$i++){
                            
                            try {
                                $query2 = $db->prepare("SELECT hotel_rezervace_idUzivatel FROM hotel_rezervace WHERE hotel_rezervace_idPokoj = ? AND hotel_rezervace_den = ?");
                            } catch (PDOException $e) {
                                die($e->getMessage());
                            }
                            //parametry
                            $params = array($hotel_pokoje_id, $i);
                            //dotaz spustim
                            try {
                                $query2->execute($params);
                            } catch (PDOException $e) {
                                die($e->getMessage());
                            }
                            $pom = $query2->fetchColumn(0);
                            if($pom == $id) {
                                //v pomocn ulozen vysledek dotazu na obsazenost pokoje, pokud je shodny s mym id, muzu rusit
                                echo("<td rowspan='3'><a href='./puj_vratit.php?id=$hotel_pokoje_id&den=$i'>Zrusit</a></td>\n");
                            } else if($pom > 0) {
                                //pokud nebyl vysledek moje ID, ale nabyva nejake hodnoty, je jiz pokoj obsazen
                                echo("<td rowspan='3'>Obsazeno</td>\n");
                            } else {
                                //v ostatnich pripadech lze rezervovat
                                echo("<td rowspan='3'><a href='./puj_pujcit.php?id=$hotel_pokoje_id&den=$i'>Rezervovat</a></td>\n");  
                              }                            
                            }
                                 
                            echo ("<tr> <td>$hotel_pokoje_popis</td></tr>
                                  <tr> <td>Kapacita: $hotel_pokoje_kapacita</td></tr> ");
                            
                            }
                        echo("</table>");      
                    } else {
                        //pokud si stranku prohlizi neprihlaseny uzivatel, zobrazim mu pouze prehled a hlaseni ze se musi prihlasit
                        echo("<table border='1'>\n");
                        echo("<tr> <th>Pokoj</th> <th>Pond�l�</th> <th>�ter�</th> <th>St�eda</th> <th>�tvrtek</th> <th>P�tek</th> <th>Sobota</th> <th>Ned�le</th> </tr>\n");
                        while($row = $query->fetch(PDO::FETCH_BOTH)) {                        			
                            //vytahnu si id pokoje - kvuli pujcovani a vraceni
                            $hotel_pokoje_id = $row['hotel_pokoje_id'];
                            $hotel_pokoje_cislo = $row['hotel_pokoje_cislo'];
                            $hotel_pokoje_popis = $row['hotel_pokoje_popis'];
                            $hotel_pokoje_kapacita = $row['hotel_pokoje_kapacita'];
                        
                            echo("<tr> <td>$hotel_pokoje_cislo</td>");
                            
                            for ($i = 0; $i < 7;$i++){
                            
                                echo("<td rowspan='3'>Nutno se prihlasit</td>\n");
                            }
                            
                                 
                            echo ("<tr> <td>$hotel_pokoje_popis</td></tr>
                                  <tr> <td>Kapacita: $hotel_pokoje_kapacita</td></tr> ");
                  
                        }
                        echo("</table>");  
                    }
                ?>
            </div>
        </div>
        <!--div pro login, zobrazuje bud prihlasovaci, nebo odhlasovaci formular podle stavu uzivatele, je v extra wrapperu, kvuli layoutu a border-->
        <div id="wrap_login">
            <div id="login">
                <?php
                    if(!isLoggedIn()) {
                        //pokud je uzivatel odhlasen zobrazuje prihlasovaci formular
                        echo("<form action='' method='POST'>\n");
                        echo("login: <input type='text' name='puj_login'><br>\n");
                        echo("heslo: <input type='password' name='puj_heslo'><br>\n");
                        echo("<input type='submit' name='puj_prihl' value='Prihlasit'>\n");
                        //pokud nekde pred tim nastala chyba - promenna pro chybu neni prazdna tak ji vypis
                        if($chyba != '') {
                            echo("<p class='error'> $chyba </p>\n");
                        }
                        echo("</form>\n");
                        //link na registracni formular
                        echo("<a href='./puj_register.php'>Registrace</a>\n");
                    } else {
                        //pokud je uzivatel prihlasen, zobrazuje kdo je prihlasen a formular pro odhlaseni
                        echo("Prihlasen: " . getUserLogin($_SESSION[session_id()], $db) . "<br>\n");
                        echo("<form action='' method='POST'>\n");
                        echo("<input type='submit' name='puj_odhl' value='Odhlasit'>\n");
                        echo("</form>\n");
                        echo "<a href='./rezervace.php'>Moje rezervace</a> ";
                      
                        
                    }
                    
                ?>
            </div>
        </div>
    </body>
</html>
<?php
    //output buffering
    ob_end_flush();
?>