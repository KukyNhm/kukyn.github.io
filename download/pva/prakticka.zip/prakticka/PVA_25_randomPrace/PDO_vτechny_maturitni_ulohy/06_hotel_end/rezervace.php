<?php
ob_start();
require_once './db_connect_PDO.php';
require_once'./scripts_PDO.php';
session_start();
   $id = $_SESSION[session_id()];
   $uzivatel = getUserLogin($_SESSION[session_id()], $db);
   
   echo "<h1>Moje rezervace</h1><br />";
   echo "uzivatel: $uzivatel a jeho rezervace<br /><br />";
   
   //dlouhy, ale asi jediny mozny dotaz jak vytahnout vsechnu rezervace
   try {
         $query = $db->prepare("SELECT hotel_pokoje_id,hotel_pokoje_cislo,hotel_pokoje_popis,hotel_pokoje_kapacita,hotel_rezervace_den 
     FROM hotel_pokoje JOIN hotel_rezervace ON hotel_pokoje.hotel_pokoje_id = hotel_rezervace.hotel_rezervace_idPokoj
      WHERE hotel_rezervace_idUzivatel = ?");  
   } catch (PDOException $e) {
       die($e->getMessage());
    } 
    
   //parametry
    $params = array($id);
     //dotaz spustim
    try {
        $query->execute($params);
    } catch (PDOException $e) {
        die($e->getMessage());
    } 
    echo "<table border=\'1\'>";
    echo("<tr> <td>ID pokoje</td><td>Kapacita</td><td>Cislo pokoje</td><td>Popis pokoje</td><td>Den (0-pondeli)-(6-nedele)</td>
          </tr>");  
                         
                          while($row = $query->fetch(PDO::FETCH_BOTH)) {                        			
                            
                            $hotel_pokoje_id = $row['hotel_pokoje_id'];
                            $hotel_pokoje_kap = $row['hotel_pokoje_kapacita'];
                            $hotel_pokoje_cislo = $row['hotel_pokoje_cislo'];
                            $hotel_pokoje_popis = $row['hotel_pokoje_popis'];
                            $den = $row['hotel_rezervace_den'];
                            
                            echo("<tr> <td>$hotel_pokoje_id</td>
                              <td>$hotel_pokoje_kap</td>
                              <td>$hotel_pokoje_cislo</td>
                              <td>$hotel_pokoje_popis</td>
                              <td>$den</td>
                              <td><a href='./puj_vratit.php?id=$hotel_pokoje_id&den=$den'>Zrusit</a></td></tr>\n");
       
                          } 
                          echo "</table>";
                          echo "<a href='./puj_index.php'>Zpet</a> ";  
                          
                          ?>              