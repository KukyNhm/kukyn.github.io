<?php
    //script pro vraceni knihy - vyzaduje v REQUESTU id vracene knihy
    //nastartovani prace se session
    session_start();
    //output buffering - kvuli hlasce s odeslanymi hlavickami
    ob_start();
    //require souboru pro pripojeni k db
    require_once './db_connect_PDO.php';
    //require souboru s  funkcemi
    require_once'./scripts_PDO.php';
    //vratit knihu muze pouze prihlaseny uzivatel	
?>    
    <fieldset><legend>Vyhledavani podle jmena</legend>
    <form action='' method='POST'>
    Jmeno<input type='text' name='jmeno'><br><br />
    Domacnosti<input type='checkbox' name='typ' value='1'><br><br />
    Firmy<input type='checkbox' name='typ1' value='1'><br><br />
    <input type='submit' name='zdar' value='Odeslat'>
    </form>  
    </fieldset><br><br> 


<?php
    if(isLoggedIn()) {
      if(isset($_REQUEST['zdar'])){
        $firma = $_REQUEST['typ1'];
        $domacnost =  $_REQUEST['typ'];
        $jmeno = $_REQUEST['jmeno']; 
        echo $domacnost;
        echo $firma;
        echo $jmeno;
        if (($firma != 1 && $domacnost !=1)|| $jmeno ==""){
        //header("Location: ./puj_index.php");
        die;
        }
        if($firma == 1){
                        try {
                            $query = $db->prepare("SELECT * FROM telefony_firmy WHERE telefony_firmy_nazev LIKE '?'");
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                        $jmeno = "%$jmeno%";
                        //parametry
                        $params = array($jmeno);
                        //Dotaz spustim
                        try {
                            $query->execute($params);
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                        
                        echo "<h1>Firmy</h1><br />";
                        echo("<table border='1'>\n");
                        echo("<tr> <th>Nazev</th><th>Ico</th><th>Mesto</th> <th>Telefon</th></tr>\n");
                        while($row = $query->fetch(PDO::FETCH_BOTH)) {
                            $typ="firma";
                            //vytahnu si id knihy - kvuli pujcovani a vraceni
                            $dom_id = $row['telefony_firmy_id'];
                            //nazev knihy kvuli vypisu
                            $fir_jmeno = $row['telefony_firmy_nazev'];
                            //zanr knihy kvuli vypisu
                            $fir_ico = $row['telefony_firmy_ico'];
                            //pocet knih kvuli vypisu a moznosti poujcovat si
                            $fir_mesto = $row['telefony_firmy_mesto'];
                            $fir_tel = $row['telefony_firmy_telefon'];
                            //zjistim si zda dany uzivatel nema pujcenu danou knihu
                            
                            echo("<tr><td>$fir_jmeno</td> <td>$fir_ico</td><td>$fir_mesto</td><td>$fir_tel</td>");                            
                            
                        }
                        echo("</table><br />");
        }
        
        if ($domacnost == 1){
                        try {
                            $query2 = $db->prepare("SELECT * FROM telefony_domacnosti WHERE telefony_domacnosti_jmeno LIKE '%?%'");
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                        //parametry
                        $params = array($jmeno);
                        //Dotaz spustim
                        try {
                            $query2->execute($params);
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
        
           

                        echo "<h1>Domacnosti</h1><br />";
                        echo("<table border='1'>\n");
                        echo("<tr> <th>Jmeno</th><th>Mesto</th> <th>Telefon</th></tr>\n");
                        while($row = $query2->fetch(PDO::FETCH_BOTH)) {
                            //vytahnu si id knihy - kvuli pujcovani a vraceni
                            $dom_id = $row['telefony_domacnosti_id'];
                            //nazev knihy kvuli vypisu
                            $dom_jmeno = $row['telefony_domacnosti_jmeno'];
                            //zanr knihy kvuli vypisu
                            $dom_mesto = $row['telefony_domacnosti_mesto'];
                            //pocet knih kvuli vypisu a moznosti poujcovat si
                            $dom_tel = $row['telefony_domacnosti_telefon'];
                            echo("<tr><td>$dom_jmeno</td> <td>$dom_mesto</td> <td>$dom_tel</td>");
                            
                            
                        }
                        echo("</table><br />");
      }}
    } else {header("Location: ./puj_index.php");}
    //presmeruji zpet na index

    //output buffering - kvuli hlasce s odeslanymi hlavickami
    ob_end_flush();
?>