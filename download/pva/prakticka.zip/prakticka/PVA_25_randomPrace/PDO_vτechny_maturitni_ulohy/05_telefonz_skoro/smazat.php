<?php
    //script pro vypujceni knihy - vyzaduje v REQUESTU id pujcovane knihy
    //nastartovani prace se session
    session_start();
    //output buffering - kvuli hlasce s odeslanymi hlavickami
    ob_start();
    //require souboru pro pripojeni k db
    require_once './db_connect_PDO.php';
    //require souboru s  funkcemi
    require_once'./scripts_PDO.php';
    //pujcovat muze jenom prihlaseny uzivatel
    if(isLoggedIn()) {
        //pokud prislo v REQUESTU id knihy
        if(isset($_REQUEST['id'])) {
        $id = $_REQUEST['id'];
        $typ = $_REQUEST['typ']; 
        
        if($typ == "firma"){
        try {
                $query = $db->prepare("DELETE  FROM telefony_firmy WHERE telefony_firmy_id = ?");
            } catch (PDOException $e) {
                die($e->getMessage());
            }
            //parametry
            $params = array($id);
            //dotaz spustim
            try {
                $query->execute($params);
            } catch (PDOException $e) {
                die($e->getMessage());
            }
        
        } else if ($typ == "domacnosti"){
          try {
                $query = $db->prepare("DELETE  FROM telefony_domacnosti WHERE telefony_domacnosti_id = ?");
            } catch (PDOException $e) {
                die($e->getMessage());
            }
            //parametry
            $params = array($id);
            //dotaz spustim
            try {
                $query->execute($params);
            } catch (PDOException $e) {
                die($e->getMessage());
            }
          } else {header("Location: ./puj_index.php");}
              
        }
           
            
    }
    //presmeruji zpet na index
    header("Location: ./puj_index.php");
    //output buffering - kvuli hlasce s odeslanymi hlavickami
    ob_end_flush();
?>