<?php
    //script pro vraceni knihy - vyzaduje v REQUESTU id vracene knihy
    //nastartovani prace se session
    session_start();
    //output buffering - kvuli hlasce s odeslanymi hlavickami
    ob_start();
    //require souboru pro pripojeni k db
    require_once './db_connect_PDO.php';
    //require souboru s  funkcemi
    require_once'./scripts_PDO.php';
    //vratit knihu muze pouze prihlaseny uzivatel
?>    
    <fieldset><legend>Vyberte jaky telefon chcete pridat</legend>
    <form action='' method='POST'>
    Firma<input type='radio' name='typ' value='firma' checked><br><br />
    Domacnost<input type='radio' name='typ' value='domacnost'><br><br />
    <input type='submit' name='zdar' value='Odeslat'>
    </form>  
    </fieldset><br><br> 



<?php
  if(isset($_REQUEST['zdar'])){
    $typ = $_REQUEST['typ'];
    $_SESSION[typ] = $typ;   
    if(isLoggedIn()) {
      if($typ == "firma"){
      echo "<h4>Pridani firemniho</h4><br />";
      echo "<table>";
      echo ("<form action='' method='POST'>");
      echo "<tr><td>Jmeno</td><td><input type='text' name='Jmeno'></td></tr>";
      echo "<tr><td>Mesto</td><td><input type='text' name='Mesto'></td></tr>";
      echo "<tr><td>Ico</td><td><input type='text' name='Ico'></td></tr>";
      echo "<tr><td>Telefon</td><td><input type='text' name='Telefon'></td></tr>";
      echo "<tr><td></td><td><input type='submit' name='odeslat' value='Odeslat'></td></tr>";
      echo "</table>";
      } else if($typ == "domacnost"){
      echo "<h4>Pridani domaciho</h4><br />";
      echo "<table>";
      echo ("<form action='' method='POST'>");
      echo "<tr><td>Jmeno</td><td><input type='text' name='Jmeno'></td></tr>";
      echo "<tr><td>Mesto</td><td><input type='text' name='Mesto'></td></tr>";
      echo "<tr><td>Telefon</td><td><input type='text' name='Telefon'></td></tr>";
      echo "<tr><td></td><td><input type='submit' name='odeslat' value='Odeslat'></td></tr>";
      echo "</table>";
      } else {header("Location: ./puj_index.php");}  
    }
  }
?>

<?php
   if(isset($_REQUEST['odeslat'])){
   $Jmeno= htmlspecialchars($_REQUEST['Jmeno']);
   $Mesto = htmlspecialchars($_REQUEST['Mesto']);
   $Ico = htmlspecialchars($_REQUEST['Ico']);
   $Telefon = htmlspecialchars($_REQUEST['Telefon']);
   $typ = $_SESSION[typ];
                   if(($Jmeno == "") || ($Mesto == "")|| ($Telefon == "")) {
                    header("Location: ./puj_index.php");
                    die; 
                    }
                
                
                if($typ == "firma"){
                        try {
                            $query = $db->prepare("INSERT INTO telefony_firmy (telefony_firmy_nazev,	telefony_firmy_ico,	telefony_firmy_mesto,	telefony_firmy_telefon) VALUES (?, ?,?,?)");
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                        //parametry
                        $params = array($Jmeno, $Mesto, $Ico, $Telefon );
                        //Dotaz spustim
                        try {
                            $query->execute($params);
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                         unset ($_SESSION[typ]); 
                        header("Location: ./puj_index.php");
   
               } else if ($typ == "domacnost") {
                        try {
                            $query = $db->prepare("INSERT INTO telefony_domacnosti (telefony_domacnosti_jmeno,	telefony_domacnosti_mesto,	telefony_domacnosti_telefon) VALUES (?, ?,?)");
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                        //parametry
                        $params = array($Jmeno, $Mesto, $Telefon );
                        //Dotaz spustim
                        try {
                            $query->execute($params);
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                        header("Location: ./puj_index.php");
                        unset ($_SESSION[typ]); 
               
               
               }
   }
?>  
  
<?php

    ob_end_flush();
?>  

