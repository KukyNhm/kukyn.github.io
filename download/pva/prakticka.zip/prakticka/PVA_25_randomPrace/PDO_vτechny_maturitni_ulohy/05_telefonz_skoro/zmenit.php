<?php
    //script pro vraceni knihy - vyzaduje v REQUESTU id vracene knihy
    //nastartovani prace se session
    session_start();
    //output buffering - kvuli hlasce s odeslanymi hlavickami
    ob_start();
    //require souboru pro pripojeni k db
    require_once './db_connect_PDO.php';
    //require souboru s  funkcemi
    require_once'./scripts_PDO.php';
    //vratit knihu muze pouze prihlaseny uzivatel
    if(isset($_REQUEST['id'])){
    $id = $_REQUEST['id'];
    $typ = $_REQUEST['typ'];
    }
?>    
   
<?php

    if(isLoggedIn()) {
      if($typ == "firma"){
                        try {
                            $query = $db->prepare("SELECT * FROM telefony_firmy WHERE telefony_firmy_id = ?");
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                        //parametry
                        $params = array($id );
                        //Dotaz spustim
                        try {
                            $query->execute($params);
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                        
                        while($row = $query->fetch(PDO::FETCH_BOTH)) {
                        $jmeno = $row['telefony_firmy_nazev'];
                        $ico = $row['telefony_firmy_ico'];
                        $mesto = $row['telefony_firmy_mesto'];
                        $telefon = $row['telefony_firmy_telefon'];
                        }			
      
      echo "Zmenit";
      echo ("<form action='' method='POST'>");
      echo "Jmeno<input type='text' name='Jmeno' value = '$jmeno'><br><br />";
      echo "Ico<input type='text' name='Ico' value = '$ico'><br><br />";
      echo "Mesto<input type='text' name='Mesto' value = '$mesto'><br><br />";        
      echo "Telefon<input type='text' name='Telefon' value = '$telefon'><br><br />";
      echo " <input type='submit' name='odeslat' value='Odeslat'>";

      } else if ($typ == "domacnosti"){
                        try {
                            $query = $db->prepare("SELECT * FROM telefony_domacnosti WHERE telefony_domacnosti_id = ?");
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                        //parametry
                        $params = array($id );
                        //Dotaz spustim
                        try {
                            $query->execute($params);
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                        
                        while($row = $query->fetch(PDO::FETCH_BOTH)) {
                        $jmeno = $row['telefony_domacnosti_jmeno'];
                        $mesto = $row['telefony_domacnosti_mesto'];
                        $telefon = $row['telefony_domacnosti_telefon'];
                        }			
      
      echo "Zmenit";
      echo ("<form action='' method='POST'>");
      echo "Jmeno<input type='text' name='Jmeno' value = '$jmeno'><br><br />";
      echo "Mesto<input type='text' name='Mesto' value = '$mesto'><br><br />";
      echo "Telefon<input type='text' name='Telefon' value = '$telefon'><br><br />";
      echo " <input type='submit' name='odeslat' value='Odeslat'>";

    } else {header("Location: ./puj_index.php");}
  
?>

<?php
   if(isset($_REQUEST['odeslat'])){
   $Jmeno= htmlspecialchars($_REQUEST['Jmeno']);
   $Ico = htmlspecialchars($_REQUEST['Ico']);
   $Mesto = htmlspecialchars($_REQUEST['Mesto']);
   $Telefon = htmlspecialchars($_REQUEST['Telefon']);
   
                   if(($Jmeno == '') || ($Mesto == '')|| ($Telefon == '')) {
                    //nastavim chybovou hlasku
                    $chyba = "Vyplnte login a heslo";
                }
                
                
                if($typ == "firma"){
                        try {
                            $query = $db->prepare("UPDATE telefony_firmy SET telefony_firmy_nazev = ?,	telefony_firmy_ico = ?,	telefony_firmy_mesto = ?,	telefony_firmy_telefon = ? WHERE telefony_firmy_id = ? ");
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                        //parametry
                        $params = array($Jmeno, $Ico, $Mesto, $Telefon, $id);
                        //Dotaz spustim
                        try {
                            $query->execute($params);
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        } 
                        header("Location: ./puj_index.php");
   
               } else {
                        try {
                            $query = $db->prepare("UPDATE telefony_domacnosti SET telefony_domacnosti_jmeno = ?,telefony_domacnosti_mesto = ?,	telefony_domacnosti_telefon = ? WHERE telefony_domacnosti_id = ? ");
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        }
                        //parametry
                        $params = array($Jmeno, $Mesto, $Telefon, $id);
                        //Dotaz spustim
                        try {
                            $query->execute($params);
                        } catch (PDOException $e) {
                            die($e->getMessage());
                        } 
                        header("Location: ./puj_index.php");
               
               
               
               }
   }
   }
?>  
  
<?php

    ob_end_flush();
?>  

