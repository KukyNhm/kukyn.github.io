<?php
    //nastartovani session
    session_start();
    //output buffering
    ob_start();
    //pripojeni k DB
    require_once './db_connect_PDO.php';
    //scripty
    require_once './scripts_PDO.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Prihlasovani ke zkouskam</title>
        <link rel="stylesheet" type="text/css" href="./styl.css">
    </head>
    <?php
        //promenna pro chybova hlaseni - dokud je prazdna tak nenastala zadna chyba
        $chyba = "";
        //uzivatel se chce prihlasit
        if(isset($_REQUEST['puj_prihl'])) {
            //vytahnu si jeho login a heslo
            //$login = htmlspecialchars(mysql_real_escape_string(($_REQUEST['puj_login'])));
            $login = htmlspecialchars($_REQUEST['puj_login']);
            //$heslo = htmlspecialchars(mysql_real_escape_string(($_REQUEST['puj_heslo'])));
            $heslo = htmlspecialchars($_REQUEST['puj_heslo']);
            //pokud zadal login nebo heslo prazdne, koncim s chybou
            if(($login == '') || ($heslo == '')) {
                $chyba = "Vyplnte login a heslo";
            } else {
                //jinak spocitam hash z jeho hesla
                $heslo = md5($heslo);
                //pokusim se prihlasit
                if(userLogin($login, $heslo, $db)) {
                    //pokud se to povedlo
                    //vytahnu si id uzivatele ze session
                    $id = $_SESSION[session_id()];
                    //zjistim si jeho login kvuli vypisu kdo je prihlasen
                    $login = getUserLogin($id, $db);
                } else {
                    //pokud to nenaslo shodu, vypisu chybou hlasku
                    $chyba = "Neplatny login a heslo";
                }
            }
        //uzivatel se chce odhlasit
        } else if(isset($_REQUEST['puj_odhl'])) {
            //pokusim se odhlasit
            if(!userLogout()) {
                //pokud se to nepovedlo, vypisu chybovou hlasku
                $chyba = "Odhlaseni se nezdarilo";
            }
        }
    ?>
    <body>
        <!--div pro hlavicku, zobrazuje pouze nadpis, je v extra wrapperu, kvuli layoutu a border-->
        <div id="wrap_head">
            <div id="head">
                <h1>Prihlasovani ke zkouskam</h1>
            </div>
        </div>
        <!--div pro telo, zobrazuje vsechny knihy a podle toh jestli je uzivatel prihlasen, nebo ne umoznuje jejich pujcovani, je v extra wrapperu, kvuli layoutu a border-->
        <div id="wrap_body">
            <div id="body">
                <?php
                    //vytahnu si informace o vsech knihach v db
                    try {
                        $query = $db->prepare("SELECT * FROM puj_knihy");
                    } catch (PDOException $e) {
                        die($e->getMessage());
                    }
                    try {
                        $query->execute();
                    } catch (PDOException $e) {
                        die($e->getMessage());
                    }
                    //pokud je uzivatel prihlasen
                  if(isLoggedIn()) {
                        //vytahnu si jeho id, kvuli identifikaci
                        $id = $_SESSION[session_id()];
                        echo("<table border='1'>\n");
                        echo("<tr> <th>Nazev</th><th>Datum zkousky</th> <th>Volnych mist</th> <th>&nbsp</th> </tr>\n");
                        while($row = $query->fetch(PDO::FETCH_BOTH)) {
                            //vytahnu si id knihy - kvuli pujcovani a vraceni
                            $kniha_id = $row['puj_knihy_id'];
                            //nazev knihy kvuli vypisu
                            $kniha_nazev = $row['puj_knihy_nazev'];
                            //zanr knihy kvuli vypisu
                            $kniha_zanr = $row['puj_knihy_zanr'];
                            //pocet knih kvuli vypisu a moznosti poujcovat si
                            $kniha_pocet = $row['puj_knihy_pocet'];
                            //zjistim si zda dany uzivatel nema pujcenu danou knihu
                            try {
                                $query2 = $db->prepare("SELECT COUNT(*) FROM puj_vypujcky WHERE puj_vyp_idUzivatel = ? AND puj_vyp_idKniha = ?");
                            } catch (PDOException $e) {
                                die($e->getMessage());
                            }
                            //parametry
                            $params = array($id, $kniha_id);
                            //dotaz spustim
                            try {
                                $query2->execute($params);
                            } catch (PDOException $e) {
                                die($e->getMessage());
                            }
                            echo("<tr> <td>$kniha_nazev</td><td>$kniha_zanr</td> <td>$kniha_pocet</td>");
                            if($query2->fetchColumn(0) == 1) {
                                //protoze pokud ano, vykreslim mu moznost vratit knihu s linkem na vraceni
                                echo("<td><a href='./puj_vratit.php?id=$kniha_id'>Odhlasit</a></td> </tr>\n");
                            } else if($kniha_pocet == 0) {
                                //pokud je pocet knih 0 a nema ji pujcenu tento uzivatel, nelze si ji pujcit
                                echo("<td>Obsazeno, mas smulu</td> </tr>\n");
                            } else {
                                //v ostatnich pripadech ji lze pujcit
                                echo("<td><a href='./puj_pujcit.php?id=$kniha_id'>Prihlasit</a></td> </tr>\n");
                            }
                        }
                        echo("</table><br />");      
                    } else {
                        //pokud si stranku prohlizi neprihlaseny uzivatel, zobrazim mu pouze prehled knih a hlaseni ze se musi prihlasit
                        echo("<table border='1'>\n");
                        echo("<tr> <th>Nazev</th><th>Datum zkousky</th> <th>Volnych mist</th> <th>&nbsp</th> </tr>\n");
                        while($row = $query->fetch(PDO::FETCH_BOTH)) {
                            $kniha_nazev = $row['puj_knihy_nazev'];
                            $kniha_zanr = $row['puj_knihy_zanr'];
                            $kniha_pocet = $row['puj_knihy_pocet'];
                            echo("<tr> <td>$kniha_nazev</td><td>$kniha_zanr</td> <td>$kniha_pocet</td> <td>musite se prihlasit</td> </tr>\n");
                        }
                        echo("</table><br />\n");
                    }
                ?>
            </div>
        </div>
        <!--div pro login, zobrazuje bud prihlasovaci, nebo odhlasovaci formular podle stavu uzivatele, je v extra wrapperu, kvuli layoutu a border-->
        <div id="wrap_login">
            <div id="login">
                <?php
                    if(!isLoggedIn()) {
                        //pokud je uzivatel odhlasen zobrazuje prihlasovaci formular
                        echo("<form action='' method='POST'>\n");
                        echo("login: <input type='text' name='puj_login'><br>\n");
                        echo("heslo: <input type='password' name='puj_heslo'><br>\n");
                        echo("<input type='submit' name='puj_prihl' value='Prihlasit'>\n");
                        //pokud nekde pred tim nastala chyba - promenna pro chybu neni prazdna tak ji vypis
                        if($chyba != '') {
                            echo("<p class='error'> $chyba </p>\n");
                        }
                        echo("</form>\n");
                        //link na registracni formular
                        echo("<a href='./puj_register.php'>Registrace</a>\n");
                    } else {
                        //pokud je uzivatel prihlasen, zobrazuje kdo je prihlasen a formular pro odhlaseni
                        echo("Prihlasen: " . getUserLogin($_SESSION[session_id()], $db) . "<br>\n");
                        echo("<form action='' method='POST'>\n");
                        echo("<input type='submit' name='puj_odhl' value='Odhlasit'>\n");
                        echo("</form>\n");
                        echo "<a href='./moje.php'>Moje zkousky</a> ";
                    }
                ?>
            </div>
        </div>
    </body>
</html>
<?php
    //output buffering
    ob_end_flush();
?>