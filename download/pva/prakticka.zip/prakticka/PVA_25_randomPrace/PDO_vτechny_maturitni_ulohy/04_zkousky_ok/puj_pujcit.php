<?php
    //script pro vypujceni knihy - vyzaduje v REQUESTU id pujcovane knihy
    //nastartovani prace se session
    session_start();
    //output buffering - kvuli hlasce s odeslanymi hlavickami
    ob_start();
    //require souboru pro pripojeni k db
    require_once './db_connect_PDO.php';
    //require souboru s  funkcemi
    require_once'./scripts_PDO.php';
    //pujcovat muze jenom prihlaseny uzivatel
    if(isLoggedIn()) {
        //pokud prislo v REQUESTU id knihy
        if(isset($_REQUEST['id'])) {
            //vytahnu si id z REQUESTU
            //$kniha_id = htmlspecialchars(mysql_real_escape_string(($_REQUEST['id'])));
            $kniha_id = htmlspecialchars($_REQUEST['id']);
            //vytahnu si z db pocet knih k dispozici daneho id
            try {
                $query = $db->prepare("SELECT puj_knihy_pocet FROM puj_knihy WHERE puj_knihy_id = ?");
            } catch (PDOException $e) {
                die($e->getMessage());
            }
            //parametry
            $params = array($kniha_id);
            //dotaz spustim
            try {
                $query->execute($params);
            } catch (PDOException $e) {
                die($e->getMessage());
            }
            $kniha_pocet = $query->fetchColumn(0);
            if($kniha_pocet > 0) {
                //pokud je knih vice jak 0, lze si ji vypujcit - snizim pocet knih o jedna
                try {
                     $query = $db->prepare("UPDATE puj_knihy SET puj_knihy_pocet = puj_knihy_pocet - 1 WHERE puj_knihy_id = ?");
                } catch (PDOException $e) {
                    die($e->getMessage());
                }
                //parametry
                $params = array($kniha_id);
                //dotaz spustim
                try {
                    $result = $query->execute($params);
                } catch (PDOException $e) {
                    die($e->getMessage());
                }
                //kontrola provedeni
                if($result == FALSE) {
                    die("Chyba pri update");
                }
                $id = $_SESSION[session_id()];
                //vlozim novy zaznam do tabulky vypujcky - uzivatel daneho id si pujcil knihu daneho id
                try {
                    $query = $db->prepare("INSERT INTO puj_vypujcky (puj_vyp_idUzivatel, puj_vyp_idKniha) VALUES (?, ?)");
                } catch (PDOException $e) {
                    die($e->getMessage());
                }
                //parametry
                $params = array($id, $kniha_id);
                //dotaz spustim
                try {
                    $result = $query->execute($params);
                } catch (PDOException $e) {
                    die($e->getMessage());
                }
                //kontrola provedeni
                if($result == FALSE) {
                    die("Chyba pri insert");
                }
            }
        }
    }
    //presmeruji zpet na index
    header("Location: ./puj_index.php");
    //output buffering - kvuli hlasce s odeslanymi hlavickami
    ob_end_flush();
?>