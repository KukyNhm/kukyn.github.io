<?php
ob_start();
require_once './db_connect_PDO.php';
require_once'./scripts_PDO.php';
session_start();
   $id = $_SESSION[session_id()];
   $uzivatel = getUserLogin($_SESSION[session_id()], $db);
   
   echo "<h1>Nakupni kosik</h1><br />";
   echo "uzivatel: $uzivatel a jeho kosik<br /><br />";
   

   try {
         $query = $db->prepare("SELECT * FROM  puj_knihy JOIN puj_vypujcky ON puj_knihy.puj_knihy_id = puj_vypujcky.puj_vyp_idKniha WHERE puj_vyp_idUzivatel = ?");  
   } catch (PDOException $e) {
       die($e->getMessage());
    } 
    
   //parametry
    $params = array($id);
     //dotaz spustim
    try {
        $query->execute($params);
    } catch (PDOException $e) {
        die($e->getMessage());
    } 
                      
                        echo("<table border=\"1\">");
                        echo("<tr><th>Predmet</th><th>Zkousejici</th><th>Volna mista</th><th>&nbsp;</th></tr>");
                        while($row = $query->fetch(PDO::FETCH_BOTH)){
                            $puj_knihy_id = $row['puj_knihy_id'];
                            $puj_knihy_nazev = $row['puj_knihy_nazev'];
                            $puj_knihy_zanr = $row['puj_knihy_zanr'];
                            $puj_knihy_pocet = $row['puj_knihy_pocet'];
                                                       
                            echo("<tr><td>$puj_knihy_nazev</td>
                            <td>$puj_knihy_zanr</td><td>$puj_knihy_pocet</td>
                            <td><a href='./puj_vratit.php?id=$puj_knihy_id'>zrusit</a></td>");
                            echo ("</tr>");
                            $cena = 0;
                        }    
                        echo "</table>";
                        echo "<a href='./puj_index.php'>Zpet</a> "; 
                          ?>              