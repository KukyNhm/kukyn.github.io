-- phpMyAdmin SQL Dump
-- version 3.3.3
-- http://www.phpmyadmin.net
--
-- Počítač: localhost
-- Vygenerováno: Čtvrtek 09. dubna 2015, 09:39
-- Verze MySQL: 5.1.46
-- Verze PHP: 5.3.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databáze: `zkouskovy`
--
CREATE DATABASE `zkouskovy` DEFAULT CHARACTER SET utf8 COLLATE utf8_czech_ci;
USE `zkouskovy`;

-- --------------------------------------------------------

--
-- Struktura tabulky `puj_knihy`
--

CREATE TABLE IF NOT EXISTS `puj_knihy` (
  `puj_knihy_id` int(11) NOT NULL AUTO_INCREMENT,
  `puj_knihy_nazev` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `puj_knihy_zanr` date NOT NULL,
  `puj_knihy_pocet` int(11) NOT NULL,
  PRIMARY KEY (`puj_knihy_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=15 ;

--
-- Vypisuji data pro tabulku `puj_knihy`
--

INSERT INTO `puj_knihy` (`puj_knihy_id`, `puj_knihy_nazev`, `puj_knihy_zanr`, `puj_knihy_pocet`) VALUES
(1, 'Zkouska z chemie', '0000-00-00', 1),
(2, 'Zkouska z cestiny', '2015-04-04', 2),
(3, 'Zkouska z EPA', '2015-04-03', 0),
(5, 'Zkouska z matematiky', '2015-04-15', 2),
(6, 'Zkouska z maturity', '2015-04-29', 0);

-- --------------------------------------------------------

--
-- Struktura tabulky `puj_vypujcky`
--

CREATE TABLE IF NOT EXISTS `puj_vypujcky` (
  `puj_vyp_id` int(11) NOT NULL AUTO_INCREMENT,
  `puj_vyp_idUzivatel` int(11) NOT NULL,
  `puj_vyp_idKniha` int(11) NOT NULL,
  PRIMARY KEY (`puj_vyp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=20 ;

--
-- Vypisuji data pro tabulku `puj_vypujcky`
--

INSERT INTO `puj_vypujcky` (`puj_vyp_id`, `puj_vyp_idUzivatel`, `puj_vyp_idKniha`) VALUES
(15, 1, 5),
(16, 1, 3),
(17, 1, 2),
(18, 1, 1),
(19, 5, 1);

-- --------------------------------------------------------

--
-- Struktura tabulky `uziv`
--

CREATE TABLE IF NOT EXISTS `uziv` (
  `uziv_id` int(11) NOT NULL AUTO_INCREMENT,
  `uziv_login` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `uziv_heslo` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`uziv_id`),
  UNIQUE KEY `uziv_login` (`uziv_login`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=6 ;

--
-- Vypisuji data pro tabulku `uziv`
--

INSERT INTO `uziv` (`uziv_id`, `uziv_login`, `uziv_heslo`) VALUES
(1, 'uuu', 'c70fd4260c9eb90bc0ba9d047c068eb8'),
(5, 'aaa', '47bce5c74f589f4867dbd57e9ca9f808');
