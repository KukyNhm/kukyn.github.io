<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="" method="get">
            Delenec:<input type="number" name="delenec" /> <br />
            Delitel:<input type="number" name="delitel" /> <br />
            Pocet desetinnych mist:<input type="number" name="pocet" /> <br />
            <input type="submit" name="pocitej" value="pocitej"/>
        </form>
        <?php
        $cislo1 = 355;
        $cislo2 = 113;

        if (isset($_REQUEST['pocitej'])) {
            //Trim - odstraní " bílé znaky " (mezery)
            //htmlspecialchars - převede nebezpečné znaky na entity
            $delenec = trim(htmlspecialchars($_REQUEST['delenec']));
            $delitel = trim(htmlspecialchars($_REQUEST['delitel']));
            $pocet = trim(htmlspecialchars($_REQUEST['pocet']));

            $vysledek = (int) ($delenec / $delitel);
            $zbytek = $delenec % $delitel;

            if ((is_numeric($delenec)) && (is_numeric($delitel)) && (is_numeric($pocet)) && ($delitel != 0)) {
                echo("$delenec / $delitel = " . $vysledek);

                if ($pocet != 0) {
                    $delenec = $zbytek * 10;
                    echo(",");
                    for ($i = 0; $i < $pocet; $i++) {
                        $vysl = (int) ($delenec / $delitel);
                        echo ($vysl);
                        $zby = $delenec % $delitel;
                        $delenec = $zby * 10;
                    }
                }
            } else {
                echo("<p style='color:red'> Dělitel nemůže být 0 </p>");
            }
        }
        ?>
    </body>
</html>
