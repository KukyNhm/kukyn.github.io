<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Goniometriky --> Algebraicky</title>
    </head>
    <body>
        <h1>Převody komplexních čísel</h1>
        <form action="" method="POST">
            <fieldset>
                <legend>Goniometricky --> Algebraicky</legend>
                <table>              
                    <tr><td> Absolutní hodnota:</td>   <td><input type="number" name='abs' value="" /></td></tr> 
                    <tr><td> Uhel:</td>    <td><input type="number" name='angle' value="" /> </td></tr> 
                    <tr><td> <input type='submit' name='vypocti' value='Vypočítej' /></td></tr> 
                </table>  
            </fieldset>
        </form>
    </body>
</html>
<?php
/**
 * @author "Jakub Čábera"
 */
if (isset($_REQUEST['vypocti'])) {
    if (trim(htmlspecialchars($_REQUEST['abs'])) || trim(htmlspecialchars($_REQUEST['angle'])) != 0) {
        $absolut = trim(htmlspecialchars($_REQUEST['abs']));
        $uhel = trim(htmlspecialchars($_REQUEST['angle']));
        $a = round($absolut * (cos(deg2rad($uhel))), 3);
        $b = round($absolut * (sin(deg2rad($uhel))), 3);
        $vypocet .= "$absolut * (cos($uhel) + i * sin($uhel))" . " = $a + $b * i";
        echo "<br />";
        echo $vypocet;
    } else {
        echo "Division by zero!";
    }
}
?>