<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="" method="POST">

            Hodnoty odporu<br />
            R1:<input type="text" name="r1" value="<?php echo($r1) ?>"/><br />
            R2:<input type="text" name="r2" value="<?php echo($r2) ?>"/><br />
            Řazení odporu<br />
            Seriové: <input type="radio" name="typ" value="ser" /><br />
            Paralelní: <input type="radio" name="typ" value="par"  /><br />
            <input type="submit" name="submit" value="odeslat" />
        </form>        
        <?php
        //pokud uživatel klikl na odeslat
        if (isset($_REQUEST['submit'])) {
            //Ochrana vstupů
            $r1 = trim(htmlspecialchars($_REQUEST['r1']));
            $r2 = trim(htmlspecialchars($_REQUEST['r2']));

            if (((is_numeric($r1)) && (is_numeric($r2))) && (($r1 != 0) && ($r2 != 0))) {
                $typ = $_POST['typ'];
                if ($typ == 'ser') {
                    $vysl = $r1 + $r2;
                    echo "vysledek serioveho zapojeni je: " . $vysl . "&Omega;";
                } else {
                    $vysl = ($r1 * $r2) / ($r1 + $r2);
                    echo "vysledek paralelniho zapojeni je: " . $vysl . " &Omega;";
                }
            } else {
                echo("<p>Neplatné vstupy</p>\n");
            }
        }
        ?>
    </body>
</html>
