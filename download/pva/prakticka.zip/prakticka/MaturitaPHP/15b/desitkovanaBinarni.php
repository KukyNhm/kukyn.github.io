<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Bin Dec</title>
    </head>
    <body>
        <fieldset>
            <legend>Program pro prevod mezi ciselnymi soustavami</legend>
            <form action='' method='POST'>
                Cislo (Des / bin): <input type='number' name='hodnota' required><br><br />
                Prevod do soustavy :
                <select name="soustava">
                    <option value="bin" selected>Dvojkova (z desitkove) </option>
                    <option value="des"> Desitkova (z binarni)  </option>
                </select> <br />
                <input type='submit' name='pocitej' value='Pocitej'>
            </form>
        </fieldset>
        <?php
        if (isset($_REQUEST['pocitej'])) {
            $number = trim($_REQUEST['hodnota']);
            $select = $_REQUEST['soustava'];
            echo "cislo $number je v soustave ";
            if ($select == "bin") {
                echo "dvojkove: " . decbin($number);
            } else if ($select == 'des') {
                // overeni binarniho formatu cisla
                if (preg_match('#[^0-1]+#', $number)) {
                    echo('<div style="font-size: 20px; color: #ad1c36">Číslo není platné binární číslo</div>');
                } else {
                    echo "desitkove: " . bindec($number);
                }
            }
        }
        ?>
    </body>
</html>
