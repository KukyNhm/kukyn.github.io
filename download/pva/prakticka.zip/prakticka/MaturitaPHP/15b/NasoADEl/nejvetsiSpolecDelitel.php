<?php

function gcd($a, $b) {
    if ($a < 1 || $b < 1) {
        die("a or b is less than 1");
    }
    $r = 0;
    do {
        $r = $a % $b;
        $a = $b;
        $b = $r;
    } while ($b != 0);

    return $a;
}


?>
<?php
if (isset($_REQUEST['hledej'])) {
//Trim - odstraní " bílé znaky " (mezery)
//htmlspecialchars - převede nebezpečné znaky na entity
    $prvni = trim(htmlspecialchars($_REQUEST['prvni']));
    $druhy = trim(htmlspecialchars($_REQUEST['druhy']));
    $kontrola = "";

    if ($prvni == "") {
        $kontrola = "1.";
        echo "<p style='color:red'> Nebylo zadano $kontrola cislo </p>";
    }

    if ($druhy == "") {
        $kontrola = "2.";
        echo "<p style='color:red'> Nebylo zadano $kontrola cislo </p>";
    }



    echo"vysledek je: " . gcd($prvni, $druhy);
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<html>
    <head>
        <meta charset="UTF-8">
        <title>Nejvetsi spolecny delitel</title>
    </head>
    <body>
        <form action="" method="POST">
            <table>
                <tr> <td>  Prvni cislo:</td><td><input type="number" name="prvni" /></td>  </tr>
                <tr> <td>  Druhe cislo:</td><td><input type="number" name="druhy" /></td> </tr>          
                <tr> <td colspan="2"> <input type="submit" name="hledej" value="Rozloz"/> </td></tr>
            </table>
        </form>


    </body>
</html>
