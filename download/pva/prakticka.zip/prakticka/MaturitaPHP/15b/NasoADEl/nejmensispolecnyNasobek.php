<?php

function lcm($num1, $num2) {
    $max = ($num1 > $num2) ? $num1 : $num2;
    while (1) {
        if ($max % $num1 == 0 && $max % $num2 == 0) {
            // echo "LCM of " .$num1. " and " .$num2. " is: ".$max;
            return $max;
            break;
        }
        $max = $max + 1;
    }
}
?>
<?php
if (isset($_REQUEST['hledej'])) {
    //Trim - odstraní " bílé znaky " (mezery)
    //htmlspecialchars - převede nebezpečné znaky na entity
    $cislo1 = trim(htmlspecialchars($_REQUEST['cislo1']));
    $cislo2 = trim(htmlspecialchars($_REQUEST['cislo2']));
    $kontrola = "";

    if ($cislo1 == "") {
        $kontrola = "1.";
        echo "<p style='color:red'> Nebylo zadano $kontrola cislo </p>";
    }
    if ($cislo2 == "") {
        $kontrola = "2.";
        echo "<p style='color:red'> Nebylo zadano $kontrola cislo </p>";
    }

    if ($kontrola == "") {

        echo"least common multiple of numbers $cislo1 & $cislo2 :  " . lcm($cislo1, $cislo2);
    }
    echo "</p>";
}
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Nejmensi spolecny nasobek</title>
    </head>
    <body>
        <form action="" method="POST">
            <table>
                <tr> <td>  Prvni cislo:</td><td><input type="number" name="cislo1" /></td>  </tr> 
                <tr> <td>  Druhe cislo:</td><td><input type="number" name="cislo2" /></td>  </tr>    
                <tr> <td colspan="2"> <input type="submit" name="hledej" value="Rozloz"/> </td></tr>
            </table>
        </form>

    </body>
</html>

