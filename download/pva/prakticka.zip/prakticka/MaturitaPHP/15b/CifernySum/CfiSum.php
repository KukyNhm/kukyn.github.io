<?php

function getSum($number) {
    $pole = array();
    while ($number > 0) {

        $pole[] = $number % 10;
        $number /=10;
    }
    foreach ($pole as $value) {
        $soucet += $value;
    }
    return $soucet;
}
?>
<?php
if (isset($_REQUEST['hledej'])) {
    //Trim - odstraní " bílé znaky " (mezery)
    //htmlspecialchars - převede nebezpečné znaky na entity
    $cislo1 = trim(htmlspecialchars($_REQUEST['cislo1']));
    $cislo2 = trim(htmlspecialchars($_REQUEST['cislo2']));
    $kontrola = "";

    if ($cislo1 == "") {
        $kontrola = "1.";
        echo "<p style='color:red'> Nebylo zadano $kontrola cislo </p>";
    }
    if ($cislo2 == "") {
        $kontrola = "2.";
        echo "<p style='color:red'> Nebylo zadano $kontrola cislo </p>";
    }

    if ($kontrola == "") {

        echo"ciferny soucet cisla $cislo1 je:  " . getSum($cislo1) .
        "<br/ > ciferny soucet cisla $cislo2 je: " . getSum($cislo2);
    }
    echo "</p>";
}
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Ciferny_soucet</title>
    </head>
    <body>
        <form action="" method="POST">
            <table>
                <tr> <td>  Prvni cislo:</td><td><input type="number" name="cislo1" /></td>  </tr> 
                <tr> <td>  Druhe cislo:</td><td><input type="number" name="cislo2" /></td>  </tr>    
                <tr> <td colspan="2"> <input type="submit" name="hledej" value="Rozloz"/> </td></tr>
            </table>
        </form>

    </body>
</html>

