<?php
session_start();
ob_start();

/**
 *  @author Tomas Vondracek
 */
class Helper {

    private static $perfect = 0;
    private static $abundant = 0;
    private static $deficient = 0;
    private static $id = 0;

    static function getId() {
        return self::$id;
    }

    static function increaseId() {
        self::$id++;
    }

    static function getPerfect() {
        return self::$perfect;
    }

    static function getAbundant() {
        return self::$abundant;
    }

    static function getDeficient() {
        return self::$deficient;
    }

    static function increasePerfect() {
        Helper::increaseId();
        self::$perfect++;
    }

    static function increaseAbundant() {
        Helper::increaseId();
        self::$abundant++;
    }

    static function increaseDeficient() {
        Helper::increaseId();
        self::$deficient++;
    }

}

function generateNumbers($number) {
    for ($index = 0; $index < $number; $index++) {
        getNumber(getRandomNumber(-500, 500));
    }
    printOccurence($number);
}

function printOccurence($number) {
    if ((Helper::getAbundant() || Helper::getDeficient() || Helper::getPerfect()) != 0) {
        $abundant = round(Helper::getAbundant() / $number * 100, 2);
        $deficient = round(Helper::getDeficient() / $number * 100, 2);
        $perfect = round(Helper::getPerfect() / $number * 100, 2);
        print "<br>Abundants: $abundant% | Deficients: $deficient% | Perfects: $perfect%";
    } else {
        print "Set quantity!";
    }
}

/**
 * 
 * @param type $min 
 * @param type $max
 * @return return pseudo random number in given range
 */
function getRandomNumber($min, $max) {
    return mt_rand($min, $max);
}

/**
 * 
 * @param take randomNumber and split it to the divisors
 */
function getNumber($number) {
    $number = abs($number);
    $divisor = 1;
    $array = array();
    while ($number != $divisor) {
        if ($number % $divisor == 0) {
            $array[] = $divisor;
        }
        $divisor++;
    }
    foreach ($array as $value) {
        $sumOfDivisors += $value;
    }
    print decideTheNumber($sumOfDivisors, $number);
}

/**
 * @param type $sumOfDivisors is sum of the divisors of the generated number
 * @param type $number whic is generated number
 * @return Type of generated number (Perfect,Deficient, Abundant)
 */
function decideTheNumber($sumOfDivisors, $number) {

    if ($sumOfDivisors > $number) {
        Helper::increaseAbundant();
        return "<br/>" . Helper::getId() . ". &emsp;$number is Abundant";
    } else if ($sumOfDivisors == $number) {
        Helper::increasePerfect();
        return "<br/>" . Helper::getId() . ".  &emsp;$number is Perfect";
    }
    Helper::increaseDeficient();
    return "<br/>" . Helper::getId() . ". &emsp; $number is Deficient";
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Type of Number</title>
    </head>
    <body>
        <style>
            body {
                background-color: #171164; /* shit browsers*/ 
                background: linear-gradient(to right,#171164,#1346a6,#2d9a9d,#96a3f6);/* standard */
                background: -moz-linear-gradient(to right,#171164,#1346a6,#2d9a9d,#96a3f6);/* firefox */
                background: -o-linear-gradient(to right,#171164,#1346a6,#2d9a9d,#96a3f6);/* opera */
                background: -webkit-linear-gradient(to right,#171164,#1346a6,#2d9a9d,#96a3f6);/* safari */
                background-attachment: fixed;
                color:#c6c6c6;
                font-family: "Geneva CE", "Arial CE", sans-serif;  

            }
            .content{
                margin: auto;
                width: 650px;                  
                text-align: center;
            }

            .generated{ 
                margin: 20px;                
                text-align: left;
                padding-left: 150px;                     

            }

            #formHeader{
                /*
                position: fixed;                
                border:#c6c6c6 solid 1px;
                */

            }
        </style>
        <div  class="content">
            <h1>Type of number</h1>
            <form action="" method="post">
                <div id="formHeader">
                    <label> Set quantity: </label>                    
                    <input type="number" name="setNumber" placeholder="default : 15" value="">
                    <button type="submit" name="submit"> Submit</button>      
                    <button type="submit" name="refresh"> Refresh</button>   
                    <hr width="85%">
                </div>
                <div class="generated">
                    <?php
                    if (isset($_REQUEST['submit'])) {
                        $_SESSION['number'] = htmlspecialchars(trim(abs($_REQUEST['setNumber'])));
                        generateNumbers($_SESSION['number']);
                    } else if (isset($_REQUEST['refresh'])) {
                        generateNumbers($_SESSION['number']);
                    } else {
                        generateNumbers(15);
                    }
                    ?>   
                </div> 
            </form>
        </div>
    </body>
</html>
