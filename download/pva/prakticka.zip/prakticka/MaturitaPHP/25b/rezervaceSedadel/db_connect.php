<?php

$dsn = "mysql:host=127.0.0.1;port=7188;dbname=kino";
$user = "root";
$password = "";
try {
    $db = new PDO($dsn, $user, $password, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        PDO::ATTR_PERSISTENT => true));
} catch (PDOException $e) {
    die('Connection failed: ' . $e->getTraceAsString());
}
?>
