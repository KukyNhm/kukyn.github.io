<?php

/* Promenne pro pripojeni k DB */
/* Data Source Name
 * - typ DB
 * - adresa serveru
 * - port
 * - jmeno DB */
$dsn = "mysql:host=127.0.0.1;port=7188;dbname=aukce";
/* Uzivatel pro pristup k DB */
$user = "root";
/* Uzivatelovo heslo */
$password = "";

/* Pripojeni k DB */
/* Vytvorime novou instanci tridy PDO */
/* Ta potrebuje dsn, uzivatele a jeho heslo a take nepovinne options
 * zde:
 * PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION - Zpusob jak bude PDO hlasit chyby ZDE zvoleno pomoci vyjimek - kvuli testovani vyjimek 
 * PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8' - Nastaveni UTF8 */
try {
    $db = new PDO($dsn, $user, $password, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8', PDO::ATTR_PERSISTENT => true));
} catch (PDOException $e) {
    /* Je zvoleno ze PDO bude vyhazovat vyjimky, takze je treba je odchytvat
     * a popr. alespon castecne zjistit co se stalo */
    echo 'Connection failed: ' . $e->getMessage();
}