<?php

session_start();
ob_start();
require_once './db_connect.php';
require_once './scripts.php';

if (isLoggedIn()) {
    //pouze prihlaseny muze vracet
    //nejprve vytahnu potrebne udaje
    $id_kniha = $_REQUEST['id_kniha'];
    $id_uziv = $_SESSION[session_id()];
    //1. smazani zaznamu z vypujcek
    try {
        $query = $db->prepare("DELETE FROM puj_vypujcky WHERE puj_vyp_idUzivatel = ? AND puj_vyp_IdKniha = ?");
        $params = array($id_uziv, $id_kniha);
        $query->execute($params);
    } catch (PDOException $e) {
        die($e->getMessage());
    }
    //2. update poctu knih
    try {
        $query = $db->prepare("UPDATE puj_knihy SET puj_knihy_pocet = puj_knihy_pocet+1 WHERE puj_knihy_id = ?");
        $params = array($id_kniha);
        $query->execute($params);
    } catch (PDOException $e) {
        die($e->getMessage());
    }
}

//navrat zpet
header("Location: ./index.php");
ob_end_flush();
?>