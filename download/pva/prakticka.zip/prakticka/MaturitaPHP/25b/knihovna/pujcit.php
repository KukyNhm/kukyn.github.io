<?php

session_start();
ob_start();
require_once './db_connect.php';
require_once './scripts.php';

if (isLoggedIn()) {
    //pouze prihlaseny muze pujcovat
    //nejprve vytahnu potrebne udaje
    $id_kniha = $_REQUEST['id_kniha'];
    $id_uziv = $_SESSION[session_id()];
    //1. vlozeni zaznamu do vypujcek
    try {
        $query = $db->prepare("INSERT INTO puj_vypujcky (puj_vyp_idUzivatel, puj_vyp_idKniha) VALUES (?, ?)");
        $params = array($id_uziv, $id_kniha);
        $query->execute($params);
    } catch (PDOException $e) {
        die($e->getMessage());
    }
    //2. update poctu knih
    try {
        $query = $db->prepare("UPDATE puj_knihy SET puj_knihy_pocet = puj_knihy_pocet-1 WHERE puj_knihy_id = ?");
        $params = array($id_kniha);
        $query->execute($params);
    } catch (PDOException $e) {
        die($e->getMessage());
    }
}

//navrat zpet
header("Location: ./index.php");
ob_end_flush();
?>